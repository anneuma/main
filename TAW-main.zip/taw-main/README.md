# TAW 2020-2021 project of group 16

## Quickstart

1. Clone this repository and open the project from Netbeans.
2. Create the Database "EventosDB".
3. Run "EventosDBscript.sql" inside "EventosDB".
4. You should now be able to build and run the project.
