/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package taw.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import static java.lang.Integer.parseInt;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import taw.dao.EventosFacade;
import taw.entity.Eventos;


public class manageEvento extends HttpServlet {

    @EJB
    EventosFacade eventosFacade;
    
    public static final String VUE          = "/newEvento.jsp";
    public static final String CHAMP_ID  = "id";
    public static final String CHAMP_NOM  = "tname";
    public static final String CHAMP_ORGANIZATOR   = "oname";
    public static final String CHAMP_PHONE   = "phone";
    public static final String CHAMP_LIEU    = "ubicacion";
    public static final String CHAMP_HEURE    = "tiempo";
    public static final String CHAMP_PLACE    = "place";
    public static final String CHAMP_PRIX    = "coste";
    public static final String CHAMP_RESUME    = "resume";
    public static final String CHAMP_TYPE    = "type";
    public static final String CHAMP_PHOTO    = "fotos";
    public static final String ATT_ERREURS  = "erreurs";
    public static final String ATT_RESULTAT = "resultat";
    
    @Override
    public void doPost( HttpServletRequest request, HttpServletResponse response ) throws ServletException, IOException {
        String resultat;
        Map<String, String> erreurs = new HashMap<String, String>();

        /* Récupération des champs du formulaire. */
        String nom = request.getParameter( CHAMP_NOM );
        String organisateur = request.getParameter( CHAMP_ORGANIZATOR );
        String phone = request.getParameter( CHAMP_PHONE );
        String lieu = request.getParameter( CHAMP_LIEU );
        int heure = Integer.parseInt(request.getParameter( CHAMP_HEURE ));
        int place = Integer.parseInt(request.getParameter( CHAMP_PLACE ));
        double prix = Double.parseDouble(request.getParameter( CHAMP_PRIX ));
        String resume = request.getParameter( CHAMP_RESUME );
        String type = request.getParameter( CHAMP_TYPE );
        String photo = request.getParameter( CHAMP_PHOTO );

        /* Validation du champ email. */
        

        /* Validation du champ nom. */
        try {
            validationNom( nom );
        } catch ( Exception e ) {
            erreurs.put( CHAMP_NOM, e.getMessage() );
        }

        /*
            On crée l'évenement et on l'ajoute
        */
        Eventos evento = new Eventos();
        Eventos check_exist;
        char type_action = 'C';
        int id;
        String page_retour = "/newEvento.jsp";
        
        if(!"".equals(request.getParameter( CHAMP_ID ))){
            /*Mise à jour*/
            id = parseInt(request.getParameter( CHAMP_ID ));
            check_exist = eventosFacade.findById(id);
            if(check_exist != null) {
                type_action = 'U';
                page_retour = "/EventList";
            }
        }else{
            /*Création*/
            do{
                Random r = new Random();
                id = r.nextInt(200000);
                check_exist = eventosFacade.findById(id);
            }while(check_exist != null);
        }
        
        evento.setIdeventos(id);
        evento.setTitulo(nom);
        evento.setCoste(prix);
        evento.setDescripcion(resume);
        evento.setNmaxentradas(place);
        evento.setFecha(heure);
        evento.setFechalim(heure);
        evento.setAforo(place);
        evento.setAsientos(photo);
        
        try {
            if(type_action == 'C'){
                eventosFacade.create(evento);
            }else{
                eventosFacade.edit(evento);
            }
                 
        } catch ( Exception e ) {
            erreurs.put( "insertion", e.getMessage() );
        }
        
        /* Initialisation du résultat global de la validation. */
        if ( erreurs.isEmpty() ) {
            resultat = "Succès de la création/mise à jour.";
        } else {
            request.setAttribute( CHAMP_NOM, nom );
            request.setAttribute( CHAMP_ORGANIZATOR, organisateur );
            request.setAttribute( CHAMP_PHONE, phone );
            request.setAttribute( CHAMP_LIEU, lieu );
            request.setAttribute( CHAMP_HEURE, heure );
            request.setAttribute( CHAMP_PLACE, place );
            request.setAttribute( CHAMP_PRIX, prix );
            request.setAttribute( CHAMP_RESUME, resume );
            request.setAttribute( CHAMP_TYPE, type );
            request.setAttribute( CHAMP_PHOTO, photo );
           
            resultat = "Échec de la création.";
        }

        /* Stockage du résultat et des messages d'erreur dans l'objet request */
        request.setAttribute("type_form", "Creación de eventos");
        request.setAttribute("action", "Crear");
        request.setAttribute( ATT_ERREURS, erreurs );
        request.setAttribute( ATT_RESULTAT, resultat );

        /* Transmission de la paire d'objets request/response à notre JSP */
        this.getServletContext().getRequestDispatcher( page_retour ).forward( request, response );
    }

    /**
    * Valide le nom saisi.
    */
    private void validationNom( String nom ) throws Exception {
        if ( nom != null && nom.trim().length() < 3 ) {
            throw new Exception( "Le nom doit contenir au moins 3 caractères." );
        }
    }
// <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
   
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        /* Affichage de la page de création */
        if (request.getParameter("id") == null) {
            request.setAttribute("type_form", "Creación de eventos");
            request.setAttribute("action", "Crear");
            this.getServletContext().getRequestDispatcher( VUE ).forward( request, response );
        } else {
            int id = parseInt(request.getParameter("id"));
           Eventos evento = eventosFacade.findById(id);
           if(evento != null){
               request.setAttribute(CHAMP_ID, id);
               request.setAttribute( CHAMP_NOM, evento.getTitulo() );
               request.setAttribute( CHAMP_ORGANIZATOR, evento.getTitulo() );
               request.setAttribute( CHAMP_PHONE, evento.getTitulo() );
               request.setAttribute( CHAMP_LIEU, evento.getTitulo() );
               request.setAttribute( CHAMP_HEURE, evento.getFecha() );
               request.setAttribute( CHAMP_PLACE, evento.getAforo() );
               request.setAttribute( CHAMP_PRIX, evento.getCoste() );
               request.setAttribute( CHAMP_RESUME, evento.getDescripcion() );
               request.setAttribute( CHAMP_TYPE, evento.getTitulo() );
               request.setAttribute( CHAMP_PHOTO, evento.getTitulo() );
               request.setAttribute("type_form", "Actualizar el evento");
               request.setAttribute("action", "Actualizar");
               this.getServletContext().getRequestDispatcher( VUE ).forward( request, response );
           }
        }
    }

 

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
